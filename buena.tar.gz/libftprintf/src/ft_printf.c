/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   printf.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/02 09:54:54 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:54:54 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ft_printf.c */
#include "ft_printf.h"

void	select_format(const char *format, va_list args, int *len)
{
	if (*format == 'c')
		ft_putchar(va_arg(args, int), len);
	else if (*format == 's')
		ft_putstr(va_arg(args, char *), len);
	else if (*format == 'd' || *format == 'i')
		ft_putnbr(va_arg(args, int), 10, "0123456789", len);
	else if (*format == 'u')
		ft_putnbr_unsigned(va_arg(args, unsigned int), \
			10, "0123456789", len);
	else if (*format == 'x')
		ft_putnbr_unsigned(va_arg(args, unsigned int), \
			16, "0123456789abcdef", len);
	else if (*format == 'X')
		ft_putnbr_unsigned(va_arg(args, unsigned int), \
			16, "0123456789ABCDEF", len);
	else if (*format == 'p')
		ft_putptr(va_arg(args, void *), len);
	else if (*format == '%')
		ft_putchar('%', len);
}

int	ft_printf(const char *format, ...)
{
	va_list	args;
	int		len;

	len = 0;
	va_start(args, format);
	while (*format)
	{
		if (*format == '%')
		{
			format++;
			select_format(format, args, &len);
		}
		else
			ft_putchar(*format, &len);
		format++;
	}
	va_end(args);
	return (len);
}
