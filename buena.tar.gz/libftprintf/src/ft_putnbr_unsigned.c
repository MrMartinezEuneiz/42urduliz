/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_unsigned.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/02 09:54:24 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:54:24 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ft_putnbr_unsigned.c */
#include "ft_printf.h"

void	ft_putnbr_unsigned(unsigned long n, int base, char *digits, int *len)
{
	if (n >= (unsigned long)base)
		ft_putnbr_unsigned(n / base, base, digits, len);
	ft_putchar(digits[n % base], len);
}
