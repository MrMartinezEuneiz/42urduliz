/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/02 09:54:47 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:54:47 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ft_putstr.c */
#include "ft_printf.h"

void	ft_putstr(char *str, int *len)
{
	if (!str)
		str = "(null)";
	while (*str)
		ft_putchar(*str++, len);
}
