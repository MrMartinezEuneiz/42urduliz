/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/02 09:54:37 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:54:37 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


/* ft_putnbr.c */
#include "ft_printf.h"

void ft_putnbr(long n, int base, char *digits, int *len) {
    if (n < 0) {
        ft_putchar('-', len);
        n = -n;
    }
    if (n >= base)
        ft_putnbr(n / base, base, digits, len);
    ft_putchar(digits[n % base], len);
}