/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putptr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/02 09:54:43 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:54:43 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


/* ft_putptr.c */
#include "ft_printf.h"

void ft_putptr(void *ptr, int *len) {
    ft_putstr("0x", len);
    ft_putnbr_unsigned((uintptr_t)ptr, 16, "0123456789abcdef", len);
}