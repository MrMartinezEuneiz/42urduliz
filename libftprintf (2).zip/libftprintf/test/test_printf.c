/* test_printf.c */
#include "../include/ft_printf.h"
#include <stdio.h>

int main(void) {
    int len1, len2;
    
    // Test básico de caracteres y strings
    len1 = ft_printf("Mi nombre es %s y mi inicial es %c\n", "Juan", 'J');
    len2 = printf("Mi nombre es %s y mi inicial es %c\n", "Juan", 'J');
    printf("ft_printf: %d, printf: %d\n", len1, len2);

    // Test de números
    len1 = ft_printf("Número: %d, Unsigned: %u, Hex: %x, HEX: %X\n", -42, 42, 42, 42);
    len2 = printf("Número: %d, Unsigned: %u, Hex: %x, HEX: %X\n", -42, 42, 42, 42);
    printf("ft_printf: %d, printf: %d\n", len1, len2);

    // Test de puntero
    int x = 42;
    len1 = ft_printf("Puntero: %p\n", &x);
    len2 = printf("Puntero: %p\n", &x);
    printf("ft_printf: %d, printf: %d\n", len1, len2);

    // Test de porcentaje
    len1 = ft_printf("Porcentaje: %%\n");
    len2 = printf("Porcentaje: %%\n");
    printf("ft_printf: %d, printf: %d\n", len1, len2);

    return 0;
}