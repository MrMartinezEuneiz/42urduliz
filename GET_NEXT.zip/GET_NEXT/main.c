#include <fcntl.h>      // open()
#include <stdio.h>      // printf(), perror()
#include <stdlib.h>     // free()
#include <unistd.h>     // close()
#include "get_next_line.h"  // tu header

// Función que lee e imprime líneas desde un file descriptor
void test_fd(int fd, const char *origen)
{
    char *line;
    int i = 1;

    printf("📝 Leyendo desde %s:\n", origen);
    while ((line = get_next_line(fd)) != NULL)
    {
        printf("Línea %d: %s", i++, line);
        free(line);
    }
    printf("📄 Fin de lectura desde %s\n\n", origen);
}

// Prueba 1: Lectura desde un archivo
void test_archivo(const char *nombre_archivo)
{
    int fd = open(nombre_archivo, O_RDONLY);
    if (fd < 0)
    {
        perror("Error al abrir el archivo");
        return;
    }
    test_fd(fd, nombre_archivo);
    close(fd);
}

// Prueba 2: Lectura desde la entrada estándar
void test_stdin(void)
{
    printf("⌨️  Introduce líneas por teclado (Ctrl+D para terminar):\n");
    test_fd(STDIN_FILENO, "stdin");
}

// Prueba 3: Archivo vacío
void test_archivo_vacio(void)
{
    int fd = open("archivo_vacio.txt", O_RDONLY | O_CREAT, 0666);
    if (fd < 0)
    {
        perror("Error al crear o abrir el archivo vacío");
        return;
    }
    test_fd(fd, "archivo vacío");
    close(fd);
}

// Prueba 4: Archivo sin salto de línea al final
void test_sin_salto_final(void)
{
    int fd = open("sin_salto.txt", O_RDONLY);
    if (fd < 0)
    {
        perror("Error al abrir sin_salto.txt");
        return;
    }
    test_fd(fd, "sin_salto.txt");
    close(fd);
}

int main(int argc, char **argv)
{
    printf("📌 Prueba: archivo pasado por argumento\n");
    if (argc == 2)
        test_archivo(argv[1]);
    else
        printf("ℹ️  Para probar lectura de archivo por argumento: ./a.out archivo.txt\n\n");

    printf("📌 Prueba: archivo sin salto de línea final\n");
    test_sin_salto_final();

    printf("📌 Prueba: archivo vacío\n");
    test_archivo_vacio();

    printf("📌 Prueba: entrada estándar (stdin)\n");
    test_stdin();

    return 0;
}


cc -Wall -Wextra -Werror -D BUFFER_SIZE=42 get_next_line.c get_next_line_utils.c main.c -o gnl_test


./gnl_test archivo.txt


./gnl_test
