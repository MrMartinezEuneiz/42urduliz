/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+        
	+:+     */
/*   By: mikemart  <mikemart @student.42.fr>        +#+  +:+      
	+#+        */
/*                                                +#+#+#+#+#+  
	+#+           */
/*   Created: 2025/03/02 09:55:12 by mikemart          #+#    #+#             */
/*   Updated: 2025/03/02 09:55:12 by mikemart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ft_printf.h */
#ifndef FT_PRINTF_H
# define FT_PRINTF_H
# include <stdarg.h>
# include <stdint.h>
# include <unistd.h>

int		ft_printf(const char *format, ...);
void	ft_putchar(char c, int *len);
void	ft_putstr(char *str, int *len);
void	ft_putnbr(long n, int base, char *digits, int *len);
void	ft_putnbr_unsigned(unsigned long n, int base, char *digits, int *len);
void	ft_putptr(void *ptr, int *len);

#endif /* FT_PRINTF_H */